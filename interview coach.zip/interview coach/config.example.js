// Copy this file to config.js and paste your Groq API key below.
// Get a key at: https://console.groq.com/keys

const GROQ_API_KEY = "YOUR_GROQ_API_KEY_HERE";
