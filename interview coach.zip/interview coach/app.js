const jobDescriptionInput = document.getElementById("jobDescription");
const resumeInput = document.getElementById("resume");
const generateBtn = document.getElementById("generateBtn");
const generateStatus = document.getElementById("generateStatus");
const questionsSection = document.getElementById("questionsSection");
const questionsList = document.getElementById("questionsList");

const GROQ_API_URL = "https://api.groq.com/openai/v1/chat/completions";
const GROQ_MODEL = "llama-3.3-70b-versatile";

function getApiKey() {
  if (typeof GROQ_API_KEY === "undefined" || !GROQ_API_KEY || GROQ_API_KEY === "YOUR_GROQ_API_KEY_HERE") {
    return null;
  }
  return GROQ_API_KEY.trim();
}

function setStatus(el, message, isError = false) {
  el.textContent = message;
  el.style.color = isError ? "var(--error)" : "var(--muted)";
}

function setButtonLoading(btn, loading, loadingText) {
  const label = btn.querySelector(".btn-label");

  if (loading) {
    if (!btn.dataset.originalText) {
      btn.dataset.originalText = label ? label.textContent : btn.textContent;
    }
    btn.disabled = true;
    btn.classList.add("is-loading");
    if (label) {
      label.textContent = loadingText;
    }
    return;
  }

  btn.disabled = false;
  btn.classList.remove("is-loading");
  const originalText = btn.dataset.originalText;
  if (label && originalText) {
    label.textContent = originalText;
  }
}

async function callGroq(messages) {
  const apiKey = getApiKey();
  if (!apiKey) {
    throw new Error("Add your Groq API key in config.js (see config.example.js).");
  }

  const response = await fetch(GROQ_API_URL, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${apiKey}`,
    },
    body: JSON.stringify({
      model: GROQ_MODEL,
      temperature: 0.7,
      messages,
    }),
  });

  if (!response.ok) {
    const err = await response.json().catch(() => ({}));
    throw new Error(err.error?.message || `Groq API error (${response.status})`);
  }

  const data = await response.json();
  const text = data.choices?.[0]?.message?.content;

  if (!text) {
    throw new Error("No response returned from Groq.");
  }

  return text.trim();
}

function parseQuestions(text) {
  const lines = text
    .split("\n")
    .map((line) => line.replace(/^\d+[\).\s-]+/, "").trim())
    .filter(Boolean);

  return lines.slice(0, 6);
}

function escapeHtml(str) {
  return str
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#39;");
}

function renderQuestions(questions) {
  questionsList.innerHTML = "";

  questions.forEach((question, index) => {
    const card = document.createElement("article");
    card.className = "question-card";
    card.innerHTML = `
      <div class="question-card-header">
        <span class="question-badge">${index + 1}</span>
        <h3>Interview Question</h3>
      </div>
      <p class="question-text">${escapeHtml(question)}</p>
      <label for="answer-${index}">Your answer</label>
      <textarea
        id="answer-${index}"
        class="answer-input"
        rows="4"
        placeholder="Type your answer here..."
      ></textarea>
      <div class="card-actions">
        <button class="btn btn-secondary feedback-btn" data-index="${index}">
          <span class="btn-label">Get Feedback</span>
        </button>
        <span class="status feedback-status" id="status-${index}"></span>
      </div>
      <div class="feedback hidden" id="feedback-${index}"></div>
    `;
    questionsList.appendChild(card);
  });

  document.querySelectorAll(".feedback-btn").forEach((btn) => {
    btn.addEventListener("click", handleFeedback);
  });

  questionsSection.classList.remove("hidden");
}

async function handleGenerate() {
  const jobDescription = jobDescriptionInput.value.trim();
  const resume = resumeInput.value.trim();

  if (!jobDescription || !resume) {
    setStatus(generateStatus, "Please paste both a job description and a resume.", true);
    return;
  }

  setButtonLoading(generateBtn, true, "Generating...");
  setStatus(generateStatus, "");

  try {
    const prompt = `You are an expert interview coach.

Based on this job description and resume, generate 5-6 realistic interview questions.
Mix behavioral, technical, and role-specific questions tailored to the candidate and role.
Return ONLY a numbered list, one question per line.

Job Description:
${jobDescription}

Resume:
${resume}`;

    const result = await callGroq([
      { role: "system", content: "You generate concise, realistic interview questions." },
      { role: "user", content: prompt },
    ]);

    const questions = parseQuestions(result);

    if (questions.length === 0) {
      throw new Error("No questions were returned. Try again.");
    }

    renderQuestions(questions);
    setStatus(generateStatus, `Generated ${questions.length} questions.`);
  } catch (error) {
    setStatus(generateStatus, error.message, true);
  } finally {
    setButtonLoading(generateBtn, false);
  }
}

async function handleFeedback(event) {
  const btn = event.currentTarget;
  const index = btn.dataset.index;
  const question = questionsList.children[index].querySelector(".question-text").textContent;
  const answer = document.getElementById(`answer-${index}`).value.trim();
  const statusEl = document.getElementById(`status-${index}`);
  const feedbackEl = document.getElementById(`feedback-${index}`);

  if (!answer) {
    setStatus(statusEl, "Please write an answer first.", true);
    return;
  }

  setButtonLoading(btn, true, "Getting feedback...");
  setStatus(statusEl, "");
  feedbackEl.classList.add("hidden");

  try {
    const prompt = `You are an interview coach. Review this interview answer.

Question:
${question}

Candidate Answer:
${answer}

Critique the answer on:
1. Clarity — Is it easy to follow?
2. Structure — Does it have a clear beginning, middle, and end?
3. Specificity — Does it use concrete examples and measurable outcomes?

Then provide a rewritten, stronger version of the answer.

Format your response as:
## Critique
- Clarity: ...
- Structure: ...
- Specificity: ...

## Stronger Version
[rewritten answer]`;

    const feedback = await callGroq([
      { role: "system", content: "You give clear, supportive interview feedback." },
      { role: "user", content: prompt },
    ]);

    feedbackEl.textContent = feedback;
    feedbackEl.classList.remove("hidden", "error");
    setStatus(statusEl, "Feedback ready.");
  } catch (error) {
    feedbackEl.textContent = error.message;
    feedbackEl.classList.remove("hidden");
    feedbackEl.classList.add("error");
    setStatus(statusEl, "Failed to get feedback.", true);
  } finally {
    setButtonLoading(btn, false);
  }
}

generateBtn.addEventListener("click", handleGenerate);
