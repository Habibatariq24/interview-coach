require("dotenv").config();

const express = require("express");
const cors = require("cors");

const app = express();
const PORT = process.env.PORT || 3000;

const ANTHROPIC_API_URL = "https://api.anthropic.com/v1/messages";
const MODEL = "claude-sonnet-4-6";

app.use(cors());
app.use(express.json({ limit: "1mb" }));
app.use(express.static("."));

async function callAnthropic(systemPrompt, userPrompt) {
  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) {
    throw new Error("ANTHROPIC_API_KEY is not set in .env");
  }

  const response = await fetch(ANTHROPIC_API_URL, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-api-key": apiKey,
      "anthropic-version": "2023-06-01",
    },
    body: JSON.stringify({
      model: MODEL,
      max_tokens: 2048,
      system: systemPrompt,
      messages: [{ role: "user", content: userPrompt }],
    }),
  });

  if (!response.ok) {
    const err = await response.json().catch(() => ({}));
    throw new Error(err.error?.message || `Anthropic API error (${response.status})`);
  }

  const data = await response.json();
  return data.content[0].text.trim();
}

app.post("/api/generate-questions", async (req, res) => {
  try {
    const { jobDescription, resume } = req.body;

    if (!jobDescription?.trim() || !resume?.trim()) {
      return res.status(400).json({ error: "Job description and resume are required." });
    }

    const systemPrompt =
      "You are an expert interview coach. Generate concise, realistic interview questions tailored to the candidate and role.";

    const userPrompt = `Based on this job description and resume, generate 5-6 realistic interview questions.
Mix behavioral, technical, and role-specific questions.
Return ONLY a numbered list, one question per line.

Job Description:
${jobDescription.trim()}

Resume:
${resume.trim()}`;

    const result = await callAnthropic(systemPrompt, userPrompt);
    res.json({ questions: result });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.post("/api/feedback", async (req, res) => {
  try {
    const { question, answer } = req.body;

    if (!question?.trim() || !answer?.trim()) {
      return res.status(400).json({ error: "Question and answer are required." });
    }

    const systemPrompt =
      "You are an interview coach. Give clear, constructive feedback on interview answers.";

    const userPrompt = `Review this interview answer and provide feedback.

Question:
${question.trim()}

Candidate Answer:
${answer.trim()}

Critique the answer on:
1. Clarity — Is the message easy to follow?
2. Structure — Does it follow a logical flow (e.g. STAR for behavioral questions)?
3. Specificity — Are there concrete examples, metrics, and outcomes?

Then provide a rewritten, stronger version of the answer.

Format your response as:
## Critique
- **Clarity:** ...
- **Structure:** ...
- **Specificity:** ...

## Stronger Version
[rewritten answer here]`;

    const result = await callAnthropic(systemPrompt, userPrompt);
    res.json({ feedback: result });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.listen(PORT, () => {
  console.log(`Interview Coach running at http://localhost:${PORT}`);
  if (!process.env.ANTHROPIC_API_KEY) {
    console.warn("Warning: ANTHROPIC_API_KEY is not set. Create a .env file to add your key.");
  }
});
