// Paste your Groq API key here.
// Get a key at: https://console.groq.com/keys

const GROQ_API_KEY = "";
